﻿笳・018/09/09
笳九し繝ｭ繧ｲ繝ｼ繝医・繧｢縺ｯ・ｰ・ｲ・ｩ・ｮ・ｴ・ｿ・ｩ・ｭ・ｧ縺ｫ莉｣譖ｿ縺励∪縺励◆ - by Jakuran
笳気hanged the Unicode surrogate pairs to PRINT_IMG instructions. - Jakuran

笳九Λ繧､繧ｻ繝ｳ繧ｹ陦ｨ險・
繝ｻ蠖鍋判蜒上ヵ繧｡繧､繝ｫ縺ｫ縺､縺・※縺ｯera謔ｪ鬲斐〒繝｡繧､繝峨ヰ繝ｪ繧｢繝ｳ繝井ｽ懆・ｻ･螟悶・蜀埼・蟶・ｒ遖√★繧