○2018/09/09
○サロゲートペアはＰＲＩＮＴ＿ＩＭＧに代替しました - by Jakuran
○Changed the Unicode surrogate pairs to PRINT_IMG instructions. - Jakuran

○ライセンス表記
・当画像ファイルについてはera悪魔でメイドバリアント作者以外の再配布を禁ずる